<?php
$user = $_POST['user'];
$pass = $_POST['pass'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aptech";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "INSERT INTO upass (username, password) VALUES ('$user', '$pass')";

if ($conn->query($sql) === TRUE) {
    header("Location: welcome.php?user=" . urlencode($user));
    exit();
} else {
  echo "Error creating account: " . $conn->error;
}

$conn->close();
?>