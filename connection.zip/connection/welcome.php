<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aptech";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user = isset($_GET['user']) ? trim($_GET['user']) : '';

if (empty($user)) {
    die('error.');
}

if (isset($_POST['delete'])) {
    $stmt = $conn->prepare("DELETE FROM upass WHERE username = ?");
    if ($stmt->execute([$user])) {
        echo 'Account deleted successfully.';
        exit();
    } else {
        $message = 'Failed to delete account.';
    }
}

if (isset($_POST['update'])) {
    $stmt = $conn->prepare("UPDATE upass SET username = ? WHERE username = ?");
    if ($stmt->execute(['Hamza', $user])) {
        $message = 'Username updated to Hamza.';
    } else {
        $message = 'Failed to update username.';
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
</head>
<body>
    <h1>Welcome, <?= htmlspecialchars($user); ?>!</h1>

    <?php if (isset($message)) : ?>
        <p><?= htmlspecialchars($message); ?></p>
    <?php endif; ?>

    <form method="post">
        <button type="submit" name="delete">Delete</button>
        <button type="submit" name="update">Update</button>
    </form>
</body>
</html>
