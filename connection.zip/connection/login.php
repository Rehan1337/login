<?php
$user = $_POST['user'];
$pass = $_POST['pass'];
$host = "localhost";  
$db_user = "root";  
$db_password = '';  
$db_name = "aptech";  
  
$con = mysqli_connect($host, $db_user, $db_password, $db_name);  

if(mysqli_connect_errno()) {  
    die("Failed to connect with MySQL: " . mysqli_connect_error());  
}

$sql = "SELECT * FROM upass WHERE username = ? AND password = ?";
$stmt = mysqli_prepare($con, $sql);

if ($stmt) {
    mysqli_stmt_bind_param($stmt, 'ss', $user, $pass);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $count = mysqli_num_rows($result);

    if($count == 1) {  
        header("Location: welcome.php?user=" . urlencode($user));
        exit();
    } else {  
        echo "<h1>Login failed. Invalid username or password.</h1>";  
    }

    mysqli_stmt_close($stmt);
} else {
    echo "<h1>Failed to prepare the SQL statement.</h1>";
}

mysqli_close($con);
?>
